﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Web;
using System.Net.Mail;

namespace RandomTestGenerator
{
    public partial class EmailUser : Form
    {
        public EmailUser()
        {
            InitializeComponent();
        }

        private void btnattach_Click(object sender, EventArgs e)
        {
            //Getting the Attachment File
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtattachment.Text = openFileDialog1.FileName.ToString();
            }
        }

        private void btnsend_Click(object sender, EventArgs e)
        {
            try 
            {
                // Creates a new email object
                MailMessage message = new MailMessage();
                String m_reciever = "";
                // Sender Email Address
                message.From = new MailAddress(txtreciever.Text, "Svetlana Marhefka");
                // Reciever Email Address
                message.To.Add(new MailAddress(txtreciever.Text));
                // Subject of the Email
                String m_subject = "Registration Confirmation - ";
                message.Subject = m_subject;
                message.Body = txtbody.Text; // Body of the email
                message.IsBodyHtml = true;

                if (txtattachment.Text != null)
                {
                    message.Attachments.Add(new Attachment(txtattachment.Text)); //Adding attachment
                }

                SmtpClient client = new SmtpClient();
                client.Host = "smtp.gmail.com";
                // client.Port = 465;
                client.Port = 587; //Connection Object
                client.Credentials = new System.Net.NetworkCredential(txtsender.Text, txtpass.Text); // Setting Credential of gmail account
                // client.UseDefaultCredentials = false;
                client.EnableSsl = true; // Enabling secured Connection
                client.Send(message); //Sending Email
                MessageBox.Show("Email Sent!");
                
                //Cursor.Current = Cursors.WaitCursor;
                //Cursor.Current = Cursors.Default;
                message = null; // Free the memory
            }
            catch (Exception ex) // Catching if any error occurs
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
