﻿namespace RandomTestGenerator
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing"> true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.l_CheckUser = new System.Windows.Forms.Button();
            this.label_username = new System.Windows.Forms.Label();
            this.label_password = new System.Windows.Forms.Label();
            this.l_username = new System.Windows.Forms.TextBox();
            this.l_password = new System.Windows.Forms.TextBox();
            this.label_des = new System.Windows.Forms.Label();
            this.RText_Description = new System.Windows.Forms.RichTextBox();
            this.l_cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // l_CheckUser
            // 
            this.l_CheckUser.AutoSize = true;
            this.l_CheckUser.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.l_CheckUser.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_CheckUser.Location = new System.Drawing.Point(40, 212);
            this.l_CheckUser.Name = "l_CheckUser";
            this.l_CheckUser.Size = new System.Drawing.Size(148, 52);
            this.l_CheckUser.TabIndex = 4;
            this.l_CheckUser.Text = "Login";
            this.l_CheckUser.UseVisualStyleBackColor = false;
            this.l_CheckUser.Click += new System.EventHandler(this.l_CheckUser_Click);
            // 
            // label_username
            // 
            this.label_username.AutoSize = true;
            this.label_username.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_username.Location = new System.Drawing.Point(27, 101);
            this.label_username.Name = "label_username";
            this.label_username.Size = new System.Drawing.Size(91, 20);
            this.label_username.TabIndex = 5;
            this.label_username.Text = "Username:";
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_password.Location = new System.Drawing.Point(27, 143);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(87, 20);
            this.label_password.TabIndex = 6;
            this.label_password.Text = "Password:";
            // 
            // l_username
            // 
            this.l_username.Location = new System.Drawing.Point(130, 101);
            this.l_username.Name = "l_username";
            this.l_username.Size = new System.Drawing.Size(322, 22);
            this.l_username.TabIndex = 7;
            // 
            // l_password
            // 
            this.l_password.Location = new System.Drawing.Point(130, 143);
            this.l_password.Name = "l_password";
            this.l_password.PasswordChar = '*';
            this.l_password.Size = new System.Drawing.Size(322, 22);
            this.l_password.TabIndex = 8;
            // 
            // label_des
            // 
            this.label_des.AutoSize = true;
            this.label_des.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_des.Location = new System.Drawing.Point(-4, 157);
            this.label_des.Name = "label_des";
            this.label_des.Size = new System.Drawing.Size(0, 21);
            this.label_des.TabIndex = 9;
            // 
            // RText_Description
            // 
            this.RText_Description.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.RText_Description.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RText_Description.Font = new System.Drawing.Font("Modern No. 20", 10.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RText_Description.ForeColor = System.Drawing.Color.Maroon;
            this.RText_Description.Location = new System.Drawing.Point(31, 25);
            this.RText_Description.Name = "RText_Description";
            this.RText_Description.ReadOnly = true;
            this.RText_Description.Size = new System.Drawing.Size(442, 55);
            this.RText_Description.TabIndex = 10;
            this.RText_Description.Text = "Please login with your given username and password";
            // 
            // l_cancel
            // 
            this.l_cancel.AutoSize = true;
            this.l_cancel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.l_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.l_cancel.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_cancel.Location = new System.Drawing.Point(293, 212);
            this.l_cancel.Name = "l_cancel";
            this.l_cancel.Size = new System.Drawing.Size(148, 52);
            this.l_cancel.TabIndex = 11;
            this.l_cancel.Text = "Cancel";
            this.l_cancel.UseVisualStyleBackColor = false;
            this.l_cancel.Click += new System.EventHandler(this.l_cancel_Click);
            // 
            // Login
            // 
            this.AcceptButton = this.l_CheckUser;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.l_cancel;
            this.ClientSize = new System.Drawing.Size(501, 322);
            this.Controls.Add(this.l_cancel);
            this.Controls.Add(this.RText_Description);
            this.Controls.Add(this.label_des);
            this.Controls.Add(this.l_password);
            this.Controls.Add(this.l_username);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.label_username);
            this.Controls.Add(this.l_CheckUser);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button l_CheckUser;
        private System.Windows.Forms.Label label_username;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.TextBox l_username;
        private System.Windows.Forms.TextBox l_password;
        private System.Windows.Forms.Label label_des;
        private System.Windows.Forms.RichTextBox RText_Description;
        private System.Windows.Forms.Button l_cancel;
    }
}