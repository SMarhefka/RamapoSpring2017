﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Security.Cryptography;
//Add the MySql Library
using MySql.Data;
using MySql.Data.MySqlClient;

namespace RandomTestGenerator
{
    public partial class Login : Form
    {
        MySqlConnection m_db_conn = null;
        DataTable m_data_table = null;
        MySqlCommand m_sql_command = null;
        MySqlDataAdapter m_sql_adapt = null;
        public int count = 0;

        public Login()
        {
            InitializeComponent();
        }

        // Click login event
        private void l_CheckUser_Click(object sender, EventArgs e)
        {
            // If the username textbox or password textbox is empty
            if (l_username.Text == "" || l_password.Text == "")
            {
                MessageBox.Show("Please provide a username and password");
                return;
            }

            m_db_conn = DBConnect.OpenConnection();
            //m_sql_connection.Open();

            count = 0;
            // Check the number of users
            m_sql_command = new MySqlCommand("SELECT * FROM user_login", m_db_conn);
            m_sql_adapt = new MySqlDataAdapter(m_sql_command);
            m_data_table = new DataTable();
            m_sql_adapt.Fill(m_data_table);
            count = m_data_table.Rows.Count;
            Console.WriteLine("Count: " + count);
            /*
            if (count <= 1)
            {
                // Then alert the user and prompt them to the registration screen

            }
            */
            m_db_conn = DBConnect.CloseConnection();
            // Reset sql variables for the next command
            m_db_conn = null;
            m_data_table = null;
            m_sql_command = null;
            m_sql_adapt = null;

            m_db_conn = DBConnect.OpenConnection();
            // Retrieve saltValue from the database
            String saltValue = "";
            m_sql_command = new MySqlCommand("SELECT Salt FROM user_login WHERE UserName = @find_username", m_db_conn);
            m_sql_command.Parameters.AddWithValue("@find_username", l_username.Text.ToString());
            MySqlDataReader sql_reader = m_sql_command.ExecuteReader();
            // Checks to see if the reader has data:
            if (sql_reader.Read())
            {
                saltValue = sql_reader.GetString(sql_reader.GetOrdinal("Salt"));
            }
            else
            {
                MessageBox.Show("Unable to find your username.  Please make sure you have entered it correctly\n");
            }
            m_db_conn = DBConnect.CloseConnection();

            // Reset sql variables for the next command
            count = 0;
            m_db_conn = null;
            sql_reader = null;
            m_sql_command = null;
            m_sql_adapt = null;
            m_data_table = null;
            m_db_conn = DBConnect.OpenConnection();
            // Set up a command with the given query and associate
            // this with the current connection.
            m_sql_command = new MySqlCommand("SELECT * FROM user_login WHERE UserName = @find_username AND Password = @find_password", m_db_conn);
            m_sql_command.Parameters.AddWithValue("@find_username", l_username.Text.ToString());
            m_sql_command.Parameters.AddWithValue("@find_password", ProgramSecurity.hashPassword(l_password.Text.ToString(), saltValue));

            m_sql_adapt = new MySqlDataAdapter(m_sql_command);
            m_data_table = new DataTable();
            m_sql_adapt.Fill(m_data_table);
            count = m_data_table.Rows.Count;

            // If count is equal to 1 and the username is admin
            if (count >= 1)
            {
                MessageBox.Show("Login Successful! You are logged in as an admin.");
                this.Hide();
                UserOptions user_options = new UserOptions();
                user_options.Show();
            }
            else
            {
                MessageBox.Show("Login Failed!");
            }
            m_db_conn = DBConnect.CloseConnection();
        }

        // If the cancel button is clicked
        private void l_cancel_Click(object sender, EventArgs e)
        {
            // Set the form to the start screen
            StartScreen start_form = new StartScreen();
            // Close the current form
            this.Hide();
            // Show the new form
            start_form.Show();
        }
    }
}