﻿namespace RandomTestGenerator
{
    partial class UserOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.u_exit = new System.Windows.Forms.Button();
            this.o_create = new System.Windows.Forms.Button();
            this.o_open = new System.Windows.Forms.Button();
            this.o_generate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // u_exit
            // 
            this.u_exit.AutoSize = true;
            this.u_exit.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.u_exit.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.u_exit.Location = new System.Drawing.Point(302, 136);
            this.u_exit.Name = "u_exit";
            this.u_exit.Size = new System.Drawing.Size(174, 68);
            this.u_exit.TabIndex = 6;
            this.u_exit.Text = "Exit";
            this.u_exit.UseVisualStyleBackColor = false;
            this.u_exit.Click += new System.EventHandler(this.u_exit_Click);
            // 
            // o_create
            // 
            this.o_create.AutoSize = true;
            this.o_create.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.o_create.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o_create.Location = new System.Drawing.Point(40, 12);
            this.o_create.Name = "o_create";
            this.o_create.Size = new System.Drawing.Size(174, 68);
            this.o_create.TabIndex = 7;
            this.o_create.Text = "Create New Test";
            this.o_create.UseVisualStyleBackColor = false;
            // 
            // o_open
            // 
            this.o_open.AutoSize = true;
            this.o_open.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.o_open.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o_open.Location = new System.Drawing.Point(302, 12);
            this.o_open.Name = "o_open";
            this.o_open.Size = new System.Drawing.Size(174, 68);
            this.o_open.TabIndex = 8;
            this.o_open.Text = "Open A Test";
            this.o_open.UseVisualStyleBackColor = false;
            // 
            // o_generate
            // 
            this.o_generate.AutoSize = true;
            this.o_generate.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.o_generate.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.o_generate.Location = new System.Drawing.Point(40, 136);
            this.o_generate.Name = "o_generate";
            this.o_generate.Size = new System.Drawing.Size(174, 68);
            this.o_generate.TabIndex = 9;
            this.o_generate.Text = "Generate A Test";
            this.o_generate.UseVisualStyleBackColor = false;
            // 
            // UserOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 233);
            this.Controls.Add(this.o_generate);
            this.Controls.Add(this.o_open);
            this.Controls.Add(this.o_create);
            this.Controls.Add(this.u_exit);
            this.Name = "UserOptions";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Options";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button u_exit;
        private System.Windows.Forms.Button o_create;
        private System.Windows.Forms.Button o_open;
        private System.Windows.Forms.Button o_generate;
    }
}