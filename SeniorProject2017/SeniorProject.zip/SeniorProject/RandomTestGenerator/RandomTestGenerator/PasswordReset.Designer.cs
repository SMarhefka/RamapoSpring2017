﻿namespace RandomTestGenerator
{
    partial class PasswordReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing"> true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.r_updatePassword = new System.Windows.Forms.Button();
            this.label_username = new System.Windows.Forms.Label();
            this.label_password = new System.Windows.Forms.Label();
            this.l_username = new System.Windows.Forms.TextBox();
            this.l_password = new System.Windows.Forms.TextBox();
            this.label_des = new System.Windows.Forms.Label();
            this.RText_Description = new System.Windows.Forms.RichTextBox();
            this.l_cancel = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // r_updatePassword
            // 
            this.r_updatePassword.AutoSize = true;
            this.r_updatePassword.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.r_updatePassword.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_updatePassword.Location = new System.Drawing.Point(79, 266);
            this.r_updatePassword.Name = "r_updatePassword";
            this.r_updatePassword.Size = new System.Drawing.Size(148, 52);
            this.r_updatePassword.TabIndex = 4;
            this.r_updatePassword.Text = "Login";
            this.r_updatePassword.UseVisualStyleBackColor = false;
            this.r_updatePassword.Click += new System.EventHandler(this.r_updatePassword_Click);
            // 
            // label_username
            // 
            this.label_username.AutoSize = true;
            this.label_username.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_username.Location = new System.Drawing.Point(93, 97);
            this.label_username.Name = "label_username";
            this.label_username.Size = new System.Drawing.Size(91, 20);
            this.label_username.TabIndex = 5;
            this.label_username.Text = "Username:";
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_password.Location = new System.Drawing.Point(58, 141);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(126, 20);
            this.label_password.TabIndex = 6;
            this.label_password.Text = "New Password:";
            // 
            // l_username
            // 
            this.l_username.Location = new System.Drawing.Point(190, 97);
            this.l_username.Name = "l_username";
            this.l_username.Size = new System.Drawing.Size(322, 22);
            this.l_username.TabIndex = 7;
            // 
            // l_password
            // 
            this.l_password.Location = new System.Drawing.Point(190, 141);
            this.l_password.Name = "l_password";
            this.l_password.PasswordChar = '*';
            this.l_password.Size = new System.Drawing.Size(322, 22);
            this.l_password.TabIndex = 8;
            // 
            // label_des
            // 
            this.label_des.AutoSize = true;
            this.label_des.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_des.Location = new System.Drawing.Point(-4, 157);
            this.label_des.Name = "label_des";
            this.label_des.Size = new System.Drawing.Size(0, 21);
            this.label_des.TabIndex = 9;
            // 
            // RText_Description
            // 
            this.RText_Description.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.RText_Description.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RText_Description.Font = new System.Drawing.Font("Modern No. 20", 10.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RText_Description.ForeColor = System.Drawing.Color.Maroon;
            this.RText_Description.Location = new System.Drawing.Point(31, 25);
            this.RText_Description.Name = "RText_Description";
            this.RText_Description.ReadOnly = true;
            this.RText_Description.Size = new System.Drawing.Size(493, 41);
            this.RText_Description.TabIndex = 10;
            this.RText_Description.Text = "Please login with your given username and password";
            // 
            // l_cancel
            // 
            this.l_cancel.AutoSize = true;
            this.l_cancel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.l_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.l_cancel.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_cancel.Location = new System.Drawing.Point(332, 266);
            this.l_cancel.Name = "l_cancel";
            this.l_cancel.Size = new System.Drawing.Size(148, 52);
            this.l_cancel.TabIndex = 11;
            this.l_cancel.Text = "Cancel";
            this.l_cancel.UseVisualStyleBackColor = false;
            this.l_cancel.Click += new System.EventHandler(this.l_cancel_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(190, 190);
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '*';
            this.textBox1.Size = new System.Drawing.Size(322, 22);
            this.textBox1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Confirm Password:";
            // 
            // PasswordReset
            // 
            this.AcceptButton = this.r_updatePassword;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.l_cancel;
            this.ClientSize = new System.Drawing.Size(567, 364);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.l_cancel);
            this.Controls.Add(this.RText_Description);
            this.Controls.Add(this.label_des);
            this.Controls.Add(this.l_password);
            this.Controls.Add(this.l_username);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.label_username);
            this.Controls.Add(this.r_updatePassword);
            this.Name = "PasswordReset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reset Password";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button r_updatePassword;
        private System.Windows.Forms.Label label_username;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.TextBox l_username;
        private System.Windows.Forms.TextBox l_password;
        private System.Windows.Forms.Label label_des;
        private System.Windows.Forms.RichTextBox RText_Description;
        private System.Windows.Forms.Button l_cancel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
    }
}