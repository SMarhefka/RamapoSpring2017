﻿namespace RandomTestGenerator
{
    partial class StartScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.m_sspicture = new System.Windows.Forms.PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.ss_login = new System.Windows.Forms.Button();
            this.ss_Register = new System.Windows.Forms.Button();
            this.ss_exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.m_sspicture)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 0;
            // 
            // m_sspicture
            // 
            this.m_sspicture.Location = new System.Drawing.Point(12, 28);
            this.m_sspicture.Name = "m_sspicture";
            this.m_sspicture.Size = new System.Drawing.Size(130, 131);
            this.m_sspicture.TabIndex = 1;
            this.m_sspicture.TabStop = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.richTextBox1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.Maroon;
            this.richTextBox1.Location = new System.Drawing.Point(154, 28);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(362, 131);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "There will be a simple description of the program here";
            // 
            // ss_login
            // 
            this.ss_login.AutoSize = true;
            this.ss_login.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ss_login.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ss_login.Location = new System.Drawing.Point(56, 223);
            this.ss_login.Name = "ss_login";
            this.ss_login.Size = new System.Drawing.Size(174, 68);
            this.ss_login.TabIndex = 3;
            this.ss_login.Text = "Login";
            this.ss_login.UseVisualStyleBackColor = false;
            this.ss_login.Click += new System.EventHandler(this.ss_login_Click);
            // 
            // ss_Register
            // 
            this.ss_Register.AutoSize = true;
            this.ss_Register.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ss_Register.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ss_Register.Location = new System.Drawing.Point(281, 223);
            this.ss_Register.Name = "ss_Register";
            this.ss_Register.Size = new System.Drawing.Size(174, 68);
            this.ss_Register.TabIndex = 4;
            this.ss_Register.Text = "Register";
            this.ss_Register.UseVisualStyleBackColor = false;
            this.ss_Register.Click += new System.EventHandler(this.ss_Register_Click);
            // 
            // ss_exit
            // 
            this.ss_exit.AutoSize = true;
            this.ss_exit.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ss_exit.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ss_exit.Location = new System.Drawing.Point(173, 338);
            this.ss_exit.Name = "ss_exit";
            this.ss_exit.Size = new System.Drawing.Size(174, 68);
            this.ss_exit.TabIndex = 5;
            this.ss_exit.Text = "Exit";
            this.ss_exit.UseVisualStyleBackColor = false;
            this.ss_exit.Click += new System.EventHandler(this.ss_exit_Click);
            // 
            // StartScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 418);
            this.Controls.Add(this.ss_exit);
            this.Controls.Add(this.ss_Register);
            this.Controls.Add(this.ss_login);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.m_sspicture);
            this.Controls.Add(this.label1);
            this.Name = "StartScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Random Test Generator: Description";
            ((System.ComponentModel.ISupportInitialize)(this.m_sspicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox m_sspicture;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button ss_login;
        private System.Windows.Forms.Button ss_Register;
        private System.Windows.Forms.Button ss_exit;
    }
}

