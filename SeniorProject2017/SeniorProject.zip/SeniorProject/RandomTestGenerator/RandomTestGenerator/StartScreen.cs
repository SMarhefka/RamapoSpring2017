﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomTestGenerator
{
    public partial class StartScreen : Form
    {
        public StartScreen()
        {
            InitializeComponent();
        }

        private void ss_login_Click(object sender, EventArgs e)
        {
            Login login_form = new Login();
            this.Hide();
            login_form.Show();
        }

        private void ss_Register_Click(object sender, EventArgs e)
        {
            Registration reg_form = new Registration();
            this.Hide();
            reg_form.Show();
        }
        // If the user clicks this button the application will be closed
        // This will also close the application process in the task bar
        // until I can get rid of it another way
        private void ss_exit_Click(object sender, EventArgs e)
        {
            
            Application.Exit();
        }
    }
}
