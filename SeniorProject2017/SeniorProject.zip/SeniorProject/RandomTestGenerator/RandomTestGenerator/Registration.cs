﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
// Allows us to use regular expressions
using System.Text.RegularExpressions;
using System.Net;
using System.Web;
using System.Net.Mail;
using System.Security.Cryptography;
//Add the MySql Library
using MySql.Data;
using MySql.Data.MySqlClient;


namespace RandomTestGenerator
{
    public partial class Registration : Form
    {
        MySqlConnection m_db_conn = null;
        DataTable m_data_table = null;
        MySqlCommand m_sql_command = null;
        MySqlDataAdapter m_sql_adapt = null;

        // A value of zero is considered false
        Byte instructorBool = 0;
        // Set first login bool to true
        Byte FLoginBool = 1;
        private int duplicate_count = 0;

        public Registration()
        {
            InitializeComponent();
        }

        private void RNewuser_Click(object sender, EventArgs e)
        {
            GatherandInsertUserInfo();
        }

        private void RCancel_Click(object sender, EventArgs e)
        {
            // Set the form to the start screen
            StartScreen start_form = new StartScreen();
            // Hide the current form
            this.Hide();
            // Show the new form
            start_form.Show();
        }

        private void GatherandInsertUserInfo()
        {
            try
            {
                if (r_fname.Text.ToString() == "")
                {
                    MessageBox.Show("Please enter your first name\n");
                }
                else if (r_lname.Text.ToString() == "")
                {
                    MessageBox.Show("Please enter your last name\n");
                }
                else if (r_school.Text.ToString() == "")
                {
                    MessageBox.Show("Please enter your school name\n");
                }
                else if (r_email.Text.ToString() == "")
                {
                    MessageBox.Show("Please enter an email\n");
                }
                string m_firstName = r_fname.Text.ToString();
                string m_lastName = r_lname.Text.ToString();
                string m_schoolName = r_school.Text.ToString();
                string m_email = "";
                // Verify that the user has entered their email address correctly
                if (IsValidEmail(r_email.Text.ToString()) == true)
                {
                    m_email = r_email.Text.ToString();
                }
                else
                {
                    MessageBox.Show("The email entered is invalid.  Please re-enter your email.\n", "Warning", MessageBoxButtons.OK);
                }
                
                if (r_instructor.Checked == true)
                {
                    // Then set the bitValue to 1 which sql will take as true
                    instructorBool = 1;
                }
                else if (r_student.Checked == true)
                {
                    // Then set the bitValue to 1 which sql will take as false
                    instructorBool = 0;
                }
                else
                {
                    MessageBox.Show("Please select if you are a student or an instructor.\n", "Warning", MessageBoxButtons.OK);
                }
                // Generate the username
                string m_userName = m_firstName.Substring(0, 1).ToLower().Trim() + m_lastName.ToLower().Trim();
                // Generate a temporary password
                string tempPassword = ProgramSecurity.generatePassword();

                int query_count = 1;
                string jquery = "";
                // Console.Write("m_userName: " + m_userName + "\n");
                jquery = "SELECT * FROM user_info WHERE UserName = @find_username";
                bool username_duplicate = IsUsernameDuplicate(jquery, m_userName, query_count);
                // Increament query count by 1
                query_count++;
                
                // If there are no duplicates usernames
                if (username_duplicate == false)
                {
                    m_db_conn = DBConnect.OpenConnection();
                    // Insert user information into the user_info table
                    InsertIntoUserInfo(m_userName, m_firstName, m_lastName, m_schoolName, m_email);
                    m_db_conn = DBConnect.CloseConnection();

                    m_db_conn = DBConnect.OpenConnection();
                    // Insert user login info into the user_login table
                    InsertIntoUserLogin(m_userName, tempPassword, instructorBool);
                    m_db_conn = DBConnect.CloseConnection();

                }
                // If there is a duplicate username
                else
                {
                    // Check to see if the user information is already
                    // in the database
                    bool user_duplicate = IsUserDuplicate(m_firstName, m_lastName, m_userName, m_email);
                    // If there there is user information that is already
                    // in the databas
                    if (user_duplicate == true)
                    {
                        // Alert the user that they are already in the database
                        MessageBox.Show("It appears that you are already in the system please try loging in\n");
                    }
                    // If the user information from the form is not the 
                    // same as the information found in the database then
                    // we just have to change the username
                    else
                    {
                        jquery = "";
                        // The query itself
                        jquery = "SELECT * FROM user_info WHERE UserName LIKE @find_username";
                        Console.WriteLine(jquery.ToString()); 
                        username_duplicate = IsUsernameDuplicate(jquery, m_userName, query_count);
                        // If there is a duplicate then attach a number to the
                        // username
                        m_userName = m_userName + duplicate_count;
                        m_db_conn = DBConnect.OpenConnection(); 
                        // Insert user information into MySqlDatabase
                        InsertIntoUserInfo(m_userName, m_firstName, m_lastName, m_schoolName, m_email);
                        m_db_conn = DBConnect.CloseConnection();

                        m_db_conn = DBConnect.OpenConnection();
                        // Insert user login info into the user_login table
                        InsertIntoUserLogin(m_userName, tempPassword, instructorBool);
                        m_db_conn = DBConnect.CloseConnection();
                    }
                }
                // rest query count
                query_count = 0;
            }
            catch (Exception m_error)
            {
                MessageBox.Show(m_error.ToString());
            }
        }

        private void InsertIntoUserInfo(string a_username, string a_firstName, string a_lastName, string a_school, string a_email)
        {
            try
            {
                m_sql_command = new MySqlCommand("INSERT INTO user_info(UserName, FirstName, LastName, School, SchoolEmail) VALUES (@insert_username, @insert_firstname, @insert_lastname, @insert_schoolname, @insert_schoolemail)", m_db_conn);
                m_sql_command.Parameters.AddWithValue("@insert_username", a_username);
                m_sql_command.Parameters.AddWithValue("@insert_firstname", a_firstName);
                m_sql_command.Parameters.AddWithValue("@insert_lastname", a_lastName);
                m_sql_command.Parameters.AddWithValue("@insert_schoolname", a_school);
                m_sql_command.Parameters.AddWithValue("@insert_schoolemail", a_email);
                m_sql_command.ExecuteNonQuery();
            }
            catch (Exception m_error)
            {
                MessageBox.Show(m_error.ToString());
            }
            
        }
        private void InsertIntoUserLogin(string a_username, string a_password, byte a_instrtype)
        {
            // Generate Salt Value
            string a_saltval = ProgramSecurity.generateSalt();
            // Hash the Generated Password
            string a_hashpass = ProgramSecurity.hashPassword(a_password, a_saltval);
            // Check to see if we can connect to the database
            m_sql_command = new MySqlCommand("INSERT INTO user_login(UserName, Password, Salt, FirstLogin, Instructor) VALUES (@insert_username, @insert_password, @insert_salt, @insert_firstlogin, @insert_instrtype)", m_db_conn);
            m_sql_command.Parameters.AddWithValue("@insert_username", a_username);
            m_sql_command.Parameters.AddWithValue("@insert_password", a_hashpass);
            m_sql_command.Parameters.AddWithValue("@insert_salt", a_saltval);
            m_sql_command.Parameters.AddWithValue("@insert_firstlogin", FLoginBool);
            m_sql_command.Parameters.AddWithValue("@insert_instrtype", a_instrtype);
            m_sql_command.ExecuteNonQuery();
        }

        private bool IsUsernameDuplicate(string a_jquery, string a_username, int a_query_count)
        {
            // Assume that we start with an empty database
            bool is_duplicate = false;
            // Check to see if we can connect to the database
            m_db_conn = DBConnect.OpenConnection();
            // Set up a command with the following query
            // Want to look in user_info and check to see if we have any duplicates
            m_sql_command = new MySqlCommand(a_jquery, m_db_conn);
            m_sql_command.Parameters.AddWithValue("@find_username", a_username.ToString());
            m_sql_adapt = new MySqlDataAdapter(m_sql_command);

            m_data_table = new DataTable();
            m_sql_adapt.Fill(m_data_table);
            int count = 0;
            count = m_data_table.Rows.Count;
            Console.WriteLine("Count: " + count);
            // Check to see if the database returned anything
            if (m_data_table == null)
            {
                MessageBox.Show("There is no data stored in the database\n");
                is_duplicate = false;
            }
            else
            {

                if (count > 0)
                {
                    Console.WriteLine("Duplicate username found in user_info\n");
                    is_duplicate = true;
                    if (a_query_count == 2)
                    {
                        duplicate_count = m_data_table.Rows.Count;
                        Console.WriteLine("duplicate_count: " + duplicate_count);
                    }
                }
                else
                {
                    Console.WriteLine("No duplicates fund\n");
                    is_duplicate = false;
                } 
            }
            m_db_conn = DBConnect.CloseConnection();
            return is_duplicate;
        }
        

        private bool IsUserDuplicate(string a_firstName, string a_lastName, string a_username, string a_email)
        {
            // Assume that we start with an empty database
            bool is_duplicate = false;
            // Check to see if we can connect to the database
            m_db_conn = DBConnect.OpenConnection();
            // Set up a command with the following query
            // Want to look in user_info and check to see if we have any duplicates
            m_sql_command = new MySqlCommand("SELECT * FROM user_info WHERE FirstName = @find_firstname AND LastName = @find_lastname AND UserName = @find_username AND SchoolEmail = @find_email", m_db_conn);
            m_sql_command.Parameters.AddWithValue("@find_username", a_username);
            m_sql_command.Parameters.AddWithValue("@find_firstname", a_firstName);
            m_sql_command.Parameters.AddWithValue("@find_lastname", a_lastName);
            m_sql_command.Parameters.AddWithValue("@find_email", a_email);

            m_sql_adapt = new MySqlDataAdapter(m_sql_command);
            m_data_table = new DataTable();
            m_sql_adapt.Fill(m_data_table);
            int count = 0;
            count = m_data_table.Rows.Count;
            if (count > 0)
            {
                Console.WriteLine("Duplicate found in user_info\n");
                is_duplicate = true;
            }
            else
            {
                Console.WriteLine("No duplicates found in user_info\n");
                is_duplicate = false;
            }
            m_db_conn = DBConnect.CloseConnection();
            return is_duplicate;
        }

        private bool IsValidEmail(string a_email)
        {
            try
            {
                var valid_email = new System.Net.Mail.MailAddress(a_email);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void EmailUser(string a_email, string a_temp_pass)
        {
            try
            {
                // *MEANS UNCOMMENT!
                // Creates a new email object
                MailMessage message = new MailMessage();
                // *String m_reciever = "";
                // Sender Email Address
                // *message.From = new MailAddress(txtreciever.Text, "Svetlana Marhefka");
                // Reciever Email Address
                // *message.To.Add(new MailAddress(txtreciever.Text));
                // Subject of the Email
                String m_subject = "Registration Confirmation - ";
                message.Subject = m_subject;
                String m_body = "";
                message.Body = m_body; // Body of the email
                message.IsBodyHtml = true;

                // Now Connect to the e-mail server
                SmtpClient client = new SmtpClient();
                client.Host = "smtp.gmail.com";
                // client.Port = 465;
                client.Port = 587;
                // Setting Credential of Gmail Account
                // *client.Credentials = new System.Net.NetworkCredential(txtsender.Text, txtpass.Text);
                // client.UseDefaultCredentials = false;
                // Enabling secured Connection
                client.EnableSsl = true;
                client.Send(message); //Sending Email
                MessageBox.Show("Email Sent!");

                //Cursor.Current = Cursors.WaitCursor;
                //Cursor.Current = Cursors.Default;
                // Free the memory
                message = null;
            }
            // Catching any errors
            catch (Exception m_error)
            {
                MessageBox.Show(m_error.ToString());
            }
        }
    }
}
