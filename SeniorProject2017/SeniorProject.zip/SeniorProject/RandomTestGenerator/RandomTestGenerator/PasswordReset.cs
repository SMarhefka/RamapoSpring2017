﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;
using System.Security.Cryptography;

namespace RandomTestGenerator
{
    public partial class PasswordReset : Form
    {
        public PasswordReset()
        {
            InitializeComponent();
        }

        // If the cancel button is clicked
        private void l_cancel_Click(object sender, EventArgs e)
        {
            // Set the form to the start screen
            StartScreen start_form = new StartScreen();
            // Close the current form
            this.Hide();
            // Show the new form
            start_form.Show();
        }

        private void r_updatePassword_Click(object sender, EventArgs e)
        {

        }
    }
}
